import React, { useState } from 'react';
import {
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Star,
  Search,
  ExternalLink,
  MessageCircle,
  RefreshCw,
  Eye,
  Check,
  Inbox,
  AlertCircle,
  X,
  Image as ImageIcon,
  Users,
  UserX,
  UserCheck,
  TrendingDown,
  Award,
} from 'lucide-react';
import { FeedbackSubmission, SheetsConfig } from '../types/feedback';

interface StaffDashboardProps {
  feedbacks: FeedbackSubmission[];
  sheetsConfig: SheetsConfig | null;
  onOpenSheetsModal: () => void;
  onUpdateStatus: (
    id: string,
    status: 'baru' | 'diproses' | 'selesai',
    notes?: string,
    staffName?: string
  ) => void;
  onSyncAll: () => Promise<void>;
  isSyncing: boolean;
}

export const StaffDashboard: React.FC<StaffDashboardProps> = ({
  feedbacks,
  sheetsConfig,
  onOpenSheetsModal,
  onUpdateStatus,
  onSyncAll,
  isSyncing,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'complaints_only' | 'urgent' | 'resolved'>(
    'complaints_only'
  );
  const [selectedStaffFilter, setSelectedStaffFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItem, setSelectedItem] = useState<FeedbackSubmission | null>(null);
  const [viewPhotoUrl, setViewPhotoUrl] = useState<string | null>(null);
  const [modalNotes, setModalNotes] = useState('');
  const [modalStatus, setModalStatus] = useState<'baru' | 'diproses' | 'selesai'>('diproses');
  const [modalStaff, setModalStaff] = useState('');

  // Stats
  const totalSubmissions = feedbacks.length;
  const complaints = feedbacks.filter(
    (f) => (f.rating ?? 5) <= 3 || (f.complaintOrFeedback || '').length > 30
  );
  const totalComplaints = complaints.length;
  const pendingComplaints = feedbacks.filter((f) => f.status !== 'selesai').length;
  const resolvedCount = feedbacks.filter((f) => f.status === 'selesai').length;

  const avgRating =
    totalSubmissions > 0
      ? (
          feedbacks.reduce((acc, curr) => acc + (curr.rating ?? 5), 0) /
          totalSubmissions
        ).toFixed(1)
      : '0.0';

  // Group performance by staff / shift
  const staffMap: Record<
    string,
    { total: number; sumRating: number; complaints: number; reviews: FeedbackSubmission[] }
  > = {};

  feedbacks.forEach((item) => {
    const key = item.staffNameOrShift?.trim() || 'Belum Terdata / Umum';
    if (!staffMap[key]) {
      staffMap[key] = { total: 0, sumRating: 0, complaints: 0, reviews: [] };
    }
    const currentRating = typeof item.rating === 'number' && !isNaN(item.rating) ? item.rating : 5;
    staffMap[key].total += 1;
    staffMap[key].sumRating += currentRating;
    if (currentRating <= 3) {
      staffMap[key].complaints += 1;
    }
    staffMap[key].reviews.push(item);
  });

  const staffStats = Object.entries(staffMap).map(([name, data]) => ({
    name,
    total: data.total,
    avg: (data.sumRating / (data.total || 1)).toFixed(1),
    complaints: data.complaints,
    needsAttention: data.complaints > 0 || data.sumRating / (data.total || 1) < 3.5,
  }));

  // Sort staff: those with complaints / low rating first so owner spots them immediately
  staffStats.sort((a, b) => b.complaints - a.complaints);

  // Filter items
  const filteredFeedbacks = feedbacks.filter((item) => {
    if (selectedStaffFilter) {
      const itemStaff = item.staffNameOrShift?.trim() || 'Belum Terdata / Umum';
      if (itemStaff !== selectedStaffFilter) return false;
    }

    const complaintText = item.complaintOrFeedback || '';
    const custName = item.customerName || '';
    const mItem = item.menuItem || '';
    const tblNo = item.tableOrOrderNo || '';
    const stf = item.staffNameOrShift || '';
    const itemId = item.id || '';

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        custName.toLowerCase().includes(q) ||
        mItem.toLowerCase().includes(q) ||
        tblNo.toLowerCase().includes(q) ||
        stf.toLowerCase().includes(q) ||
        complaintText.toLowerCase().includes(q) ||
        itemId.toLowerCase().includes(q);
      if (!match) return false;
    }

    const currentRating = typeof item.rating === 'number' && !isNaN(item.rating) ? item.rating : 5;

    if (filterType === 'complaints_only') {
      return currentRating <= 3 || complaintText.length > 15;
    }
    if (filterType === 'urgent') {
      return item.status !== 'selesai';
    }
    if (filterType === 'resolved') {
      return item.status === 'selesai';
    }
    return true;
  });

  const handleOpenDetailModal = (item: FeedbackSubmission) => {
    setSelectedItem(item);
    setModalStatus(item.status);
    setModalNotes(item.internalNotes || '');
    setModalStaff(item.staffNameOrShift || '');
  };

  const handleSaveModal = () => {
    if (!selectedItem) return;
    onUpdateStatus(selectedItem.id, modalStatus, modalNotes, modalStaff);
    setSelectedItem(null);
  };

  const formatPhoneNumberForWA = (phone: string): string => {
    let clean = phone.replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) {
      clean = '62' + clean.slice(1);
    }
    return clean;
  };

  const handleOpenWhatsApp = (item: FeedbackSubmission) => {
    if (!item.customerPhone) return;
    const phone = formatPhoneNumberForWA(item.customerPhone);
    const text = encodeURIComponent(
      `Halo Kak ${item.customerName}, salam hangat dari Pemilik JUVE JUICE New Food Terrace The Taman Dayu.\n\n` +
        `Kami menerima evaluasi tiket *${item.id}* terkait pesanan *${item.menuItem}* di *${item.tableOrOrderNo}*.\n\n` +
        `Kami memohon maaf atas ketidaknyamanan yang terjadi pada pelayanan staf kami. Masukan Kakak sedang kami evaluasi internal agar pelayanan ke depan lebih memuaskan. Terima kasih banyak Kak!`
    );
    window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
            Monitor Stand JUVE JUICE · New Food Terrace
          </span>
          <h1 className="text-2xl font-black text-stone-900 tracking-tight mt-0.5">
            Evaluasi Pelayanan &amp; Kinerja Pegawai
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Data penilaian pelanggan dari meja makan Food Terrace yang otomatis terhubung ke Google Sheets
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {sheetsConfig ? (
            <a
              href={sheetsConfig.spreadsheetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-emerald-900 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 rounded-xl transition-all shadow-xs"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
              <span>Buka Google Sheets</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          ) : (
            <button
              onClick={onOpenSheetsModal}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-all shadow-xs"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Hubungkan Spreadsheet</span>
            </button>
          )}

          <button
            onClick={onSyncAll}
            disabled={isSyncing || !sheetsConfig}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-stone-700 bg-white hover:bg-stone-50 border border-stone-200 rounded-xl transition-all shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Menyinkronkan...' : 'Sinkronkan Ulang'}</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-400 uppercase">Total Masukan</span>
          <p className="text-2xl font-black text-stone-900 font-mono mt-1">{totalSubmissions}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-400 uppercase">Rata-rata Rating</span>
          <div className="flex items-center gap-1.5 mt-1">
            <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
            <span className="text-2xl font-black text-stone-900 font-mono">{avgRating}</span>
          </div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-rose-500 uppercase">Perlu Evaluasi</span>
          <p className="text-2xl font-black text-rose-600 font-mono mt-1">{totalComplaints}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-emerald-600 uppercase">Selesai Ditindak</span>
          <p className="text-2xl font-black text-emerald-600 font-mono mt-1">{resolvedCount}</p>
        </div>
      </div>

      {/* Special Widget for Owner: Rekap Kinerja Pegawai & Shift */}
      <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-stone-900 font-extrabold text-sm">
            <Users className="w-4 h-4 text-amber-600" />
            <span>Rekap Kinerja Pegawai / Shift (Khusus Pemilik)</span>
          </div>
          {selectedStaffFilter && (
            <button
              onClick={() => setSelectedStaffFilter(null)}
              className="text-xs text-amber-700 font-semibold hover:underline flex items-center gap-1"
            >
              <span>Reset filter ({selectedStaffFilter})</span>
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <p className="text-xs text-stone-500">
          Klik pada nama pegawai/shift di bawah untuk memfilter masukan pelanggan yang mereka layani:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-1">
          {staffStats.map((st) => {
            const isSelected = selectedStaffFilter === st.name;
            return (
              <button
                key={st.name}
                type="button"
                onClick={() =>
                  setSelectedStaffFilter(isSelected ? null : st.name)
                }
                className={`p-3.5 rounded-2xl text-left border transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'border-amber-500 bg-amber-50 ring-2 ring-amber-400 shadow-xs'
                    : st.needsAttention
                    ? 'border-rose-200 bg-rose-50/60 hover:bg-rose-50'
                    : 'border-stone-200 bg-stone-50/60 hover:bg-stone-50'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="font-bold text-xs text-stone-900 truncate">
                    {st.name}
                  </div>
                  {st.needsAttention ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full shrink-0">
                      <TrendingDown className="w-3 h-3 text-rose-600" />
                      <span>{st.complaints} Keluhan</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full shrink-0">
                      <Award className="w-3 h-3 text-emerald-600" />
                      <span>Bagus</span>
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between text-xs text-stone-600 mt-2.5 pt-2 border-t border-stone-200/60">
                  <span>{st.total} pesanan</span>
                  <div className="flex items-center gap-1 font-bold text-stone-900">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                    <span>{st.avg}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Feedback List */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
        {/* Filter bar */}
        <div className="p-4 border-b border-stone-200 bg-stone-50/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1 bg-stone-200/60 p-1 rounded-xl overflow-x-auto">
            <button
              onClick={() => setFilterType('complaints_only')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                filterType === 'complaints_only'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Perlu Perhatian ({totalComplaints})
            </button>
            <button
              onClick={() => setFilterType('all')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                filterType === 'all'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Semua ({totalSubmissions})
            </button>
            <button
              onClick={() => setFilterType('urgent')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                filterType === 'urgent'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Belum Selesai ({pendingComplaints})
            </button>
          </div>

          <div className="relative min-w-[220px]">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama pegawai, menu, meja..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-stone-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
            />
          </div>
        </div>

        {/* List items */}
        {filteredFeedbacks.length === 0 ? (
          <div className="p-12 text-center text-stone-500">
            <Inbox className="w-10 h-10 mx-auto text-stone-300 mb-2" />
            <p className="text-sm font-bold text-stone-700">Belum ada masukan</p>
          </div>
        ) : (
          <div className="divide-y divide-stone-100">
            {filteredFeedbacks.map((item) => (
              <div
                key={item.id}
                className="p-5 hover:bg-stone-50/80 transition-colors flex flex-col md:flex-row md:items-start justify-between gap-4"
              >
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500">
                    <span className="font-mono font-bold text-stone-800">{item.id}</span>
                    <span>·</span>
                    <span>
                      {new Date(item.createdAt).toLocaleDateString('id-ID', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                      ,{' '}
                      {new Date(item.createdAt).toLocaleTimeString('id-ID', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    <span>·</span>
                    <span className="font-medium text-stone-700">{item.tableOrOrderNo || 'Meja -'}</span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                    <h3 className="text-base font-bold text-stone-900">{item.customerName}</h3>
                    <span className="text-xs text-amber-800 font-semibold bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">
                      {item.menuItem}
                    </span>
                    {/* Staff Tag */}
                    <span className="text-xs text-stone-700 font-medium bg-stone-100 border border-stone-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                      <Users className="w-3 h-3 text-amber-600" />
                      <span>{item.staffNameOrShift || 'Staf: Umum / Belum Terdata'}</span>
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-0.5">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star
                          key={s}
                          className={`w-3.5 h-3.5 ${
                            s <= item.rating
                              ? 'fill-amber-400 text-amber-500'
                              : 'text-stone-200'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs font-bold text-stone-700">{item.rating}/5</span>
                  </div>

                  <p className="text-xs text-stone-700 leading-relaxed bg-stone-50 p-3 rounded-xl border border-stone-200">
                    "{item.complaintOrFeedback}"
                  </p>

                  {/* Photo thumbnail if uploaded */}
                  {item.photoUrl && (
                    <button
                      type="button"
                      onClick={() => setViewPhotoUrl(item.photoUrl!)}
                      className="inline-flex items-center gap-2 p-1.5 bg-stone-100 hover:bg-stone-200 border border-stone-200 rounded-xl text-xs font-semibold text-stone-800 transition-colors"
                    >
                      <img
                        src={item.photoUrl}
                        alt="Bukti foto"
                        className="w-10 h-10 object-cover rounded-lg"
                      />
                      <span>Lihat Foto Bukti Pelanggan</span>
                    </button>
                  )}

                  {item.internalNotes && (
                    <p className="text-xs text-stone-500 italic">
                      Catatan Evaluasi Pemilik: {item.internalNotes}
                    </p>
                  )}
                </div>

                <div className="flex md:flex-col items-center md:items-end justify-between gap-2 shrink-0">
                  <div>
                    {item.status === 'selesai' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-emerald-800 bg-emerald-100 rounded-lg">
                        <Check className="w-3.5 h-3.5" />
                        <span>Selesai Dievaluasi</span>
                      </span>
                    ) : item.status === 'diproses' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-amber-800 bg-amber-100 rounded-lg">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Sedang Diproses</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-rose-800 bg-rose-100 rounded-lg">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>Perlu Tindak Lanjut</span>
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {item.customerPhone && (
                      <button
                        onClick={() => handleOpenWhatsApp(item)}
                        className="p-2 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors"
                        title="Kirim WA"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">WA</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleOpenDetailModal(item)}
                      className="px-3 py-1.5 text-xs font-semibold text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Evaluasi</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal: View Full Photo */}
      {viewPhotoUrl && (
        <div className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative bg-white rounded-3xl overflow-hidden max-w-lg w-full p-4 shadow-2xl space-y-3">
            <div className="flex justify-between items-center pb-2 border-b border-stone-100">
              <span className="text-xs font-bold text-stone-800">Foto Bukti dari Pelanggan</span>
              <button
                onClick={() => setViewPhotoUrl(null)}
                className="p-1 text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <img
              src={viewPhotoUrl}
              alt="Bukti foto keluhan"
              className="w-full max-h-[70vh] object-contain rounded-2xl bg-stone-50"
            />
          </div>
        </div>
      )}

      {/* Modal: Status & Staff Performance Follow-up */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-6 py-5 border-b border-stone-100 flex items-center justify-between">
              <h3 className="text-base font-bold text-stone-900">
                Tindak Lanjut &amp; Evaluasi Staf #{selectedItem.id}
              </h3>
              <button
                onClick={() => setSelectedItem(null)}
                className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="text-xs bg-stone-50 p-3 rounded-xl border border-stone-200 space-y-1">
                <p><strong>Pelanggan:</strong> {selectedItem.customerName} ({selectedItem.customerPhone || 'Tanpa no. WA'})</p>
                <p><strong>Menu:</strong> {selectedItem.menuItem} · {selectedItem.tableOrOrderNo}</p>
                <p><strong>Rating:</strong> {selectedItem.rating}/5 Bintang</p>
              </div>

              {/* Tag / Assign Staff Name */}
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  Pegawai / Shift yang Melayani
                </label>
                <input
                  type="text"
                  value={modalStaff}
                  onChange={(e) => setModalStaff(e.target.value)}
                  placeholder="Contoh: Rian (Shift Malam) / Siti (Kasir)"
                  className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none"
                />
                <p className="text-[10px] text-stone-400 mt-1">
                  Pemilik dapat mencatat/mengoreksi nama pegawai yang bertugas pada jam pemesanan tersebut.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1.5">
                  Ubah Status Tindak Lanjut
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['baru', 'diproses', 'selesai'] as const).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setModalStatus(st)}
                      className={`py-2 text-xs font-bold rounded-xl border transition-all capitalize ${
                        modalStatus === st
                          ? 'bg-stone-900 text-white border-stone-900'
                          : 'bg-stone-50 text-stone-700 border-stone-200'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">
                  Catatan Evaluasi Internal Pemilik (Tersimpan di Sheet)
                </label>
                <textarea
                  rows={3}
                  value={modalNotes}
                  onChange={(e) => setModalNotes(e.target.value)}
                  placeholder="Contoh: Sudah ditegur dan dibriefing mengenai SOP less sugar & estimasi antrean..."
                  className="w-full p-3 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              {selectedItem.customerPhone && (
                <button
                  type="button"
                  onClick={() => handleOpenWhatsApp(selectedItem)}
                  className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold transition-colors"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-600" />
                  <span>Buka Chat WhatsApp Pelanggan</span>
                </button>
              )}
            </div>

            <div className="px-6 py-4 bg-stone-50 border-t border-stone-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSaveModal}
                className="px-5 py-2 text-xs font-bold text-white bg-amber-500 hover:bg-amber-600 rounded-xl shadow-xs"
              >
                Simpan Evaluasi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
