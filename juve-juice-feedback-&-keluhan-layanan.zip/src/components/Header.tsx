import React from 'react';
import {
  FileSpreadsheet,
  CheckCircle2,
  QrCode,
  LayoutDashboard,
  ClipboardList,
  LogOut,
  ExternalLink,
  Lock,
  Unlock,
  ShieldAlert,
} from 'lucide-react';
import { User } from 'firebase/auth';
import { SheetsConfig } from '../types/feedback';

interface HeaderProps {
  isAdmin: boolean;
  activeTab: 'customer' | 'dashboard' | 'qr';
  setActiveTab: (tab: 'customer' | 'dashboard' | 'qr') => void;
  user: User | null;
  sheetsConfig: SheetsConfig | null;
  onOpenSheetsModal: () => void;
  onOpenAdminModal: () => void;
  onLockAdmin: () => void;
  onLogout: () => void;
  pendingComplaintsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  isAdmin,
  activeTab,
  setActiveTab,
  user,
  sheetsConfig,
  onOpenSheetsModal,
  onOpenAdminModal,
  onLockAdmin,
  onLogout,
  pendingComplaintsCount,
}) => {
  // If NOT in Admin Mode: Customer Only View!
  if (!isAdmin) {
    return (
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          {/* Brand only */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center text-white font-black text-xl tracking-tight shadow-sm">
              J
            </div>
            <div>
              <span className="font-extrabold text-lg tracking-tight text-stone-900">
                JUVE JUICE
              </span>
              <span className="block text-[11px] text-stone-500 font-medium leading-none">
                New Food Terrace · The Taman Dayu
              </span>
            </div>
          </div>

          {/* Discreet Admin Lock Button */}
          <button
            onClick={onOpenAdminModal}
            title="Akses Khusus Pemilik & Pengelola Stand"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors border border-stone-200"
          >
            <Lock className="w-3.5 h-3.5 text-stone-500" />
            <span className="hidden sm:inline">Akses Pengelola</span>
          </button>
        </div>
      </header>
    );
  }

  // If in Admin Mode: Full Controls for Owner & Staff!
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200 shadow-xs">
      {/* Top Banner Alert for Admin Mode */}
      <div className="bg-amber-500 text-white text-[11px] font-bold px-4 py-1 text-center flex items-center justify-center gap-2">
        <ShieldAlert className="w-3.5 h-3.5" />
        <span>Mode Pengelola / Pemilik Aktif (Pelanggan umum hanya melihat tampilan formulir)</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('customer')}
              className="text-left group flex items-center gap-2.5 focus:outline-none"
            >
              <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center text-white font-black text-xl tracking-tight shadow-sm group-hover:scale-105 transition-transform">
                J
              </div>
              <div>
                <span className="font-extrabold text-lg tracking-tight text-stone-900">
                  JUVE JUICE
                </span>
                <span className="block text-[11px] text-amber-700 font-bold leading-none">
                  Admin Stand
                </span>
              </div>
            </button>
          </div>

          {/* Admin Navigation */}
          <nav className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveTab('customer')}
              className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'customer'
                  ? 'bg-amber-100 text-amber-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <ClipboardList className="w-4 h-4" />
              <span>Pratinjau Form</span>
            </button>

            <button
              onClick={() => setActiveTab('dashboard')}
              className={`relative flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'dashboard'
                  ? 'bg-amber-100 text-amber-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Rekap &amp; Pegawai</span>
              {pendingComplaintsCount > 0 && (
                <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-bold bg-rose-600 text-white rounded-full">
                  {pendingComplaintsCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('qr')}
              className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'qr'
                  ? 'bg-amber-100 text-amber-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <QrCode className="w-4 h-4" />
              <span>Cetak QR Meja</span>
            </button>
          </nav>

          {/* Admin Actions */}
          <div className="flex items-center gap-2">
            {sheetsConfig ? (
              <div className="flex items-center gap-1.5">
                <a
                  href={sheetsConfig.spreadsheetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  title={`Buka Google Sheet: ${sheetsConfig.spreadsheetTitle}`}
                  className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 rounded-lg transition-colors border border-emerald-300 shadow-xs"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
                  <span className="max-w-[120px] truncate">{sheetsConfig.spreadsheetTitle}</span>
                  <ExternalLink className="w-3 h-3 text-emerald-600" />
                </a>

                <button
                  onClick={onOpenSheetsModal}
                  className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Sheet</span>
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenSheetsModal}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-500 rounded-lg transition-all shadow-xs"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span className="whitespace-nowrap">Hubungkan Sheet</span>
              </button>
            )}

            {/* Lock / Back to Customer Mode */}
            <button
              onClick={onLockAdmin}
              title="Kunci & Kembali ke Tampilan Pelanggan"
              className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-stone-800 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-lg transition-colors"
            >
              <Unlock className="w-3.5 h-3.5 text-amber-800" />
              <span className="hidden sm:inline">Kunci Mode</span>
            </button>

            {user && (
              <button
                onClick={onLogout}
                title={`Keluar akun (${user.email})`}
                className="p-1.5 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
