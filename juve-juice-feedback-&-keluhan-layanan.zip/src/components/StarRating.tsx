import React from 'react';
import { Star } from 'lucide-react';

interface StarRatingProps {
  label: string;
  sublabel?: string;
  value: number;
  onChange: (val: number) => void;
  descriptions?: Record<number, string>;
  required?: boolean;
}

const DEFAULT_DESCRIPTIONS: Record<number, string> = {
  1: 'Sangat Mengecewakan',
  2: 'Kurang Puas',
  3: 'Cukup / Standar',
  4: 'Puas & Baik',
  5: 'Sangat Memuaskan & Luar Biasa',
};

export const StarRating: React.FC<StarRatingProps> = ({
  label,
  sublabel,
  value,
  onChange,
  descriptions = DEFAULT_DESCRIPTIONS,
  required = true,
}) => {
  const [hovered, setHovered] = React.useState<number | null>(null);

  const activeScore = hovered ?? value;

  return (
    <div className="py-2">
      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-1 mb-2">
        <label className="text-sm font-semibold text-stone-800">
          {label}
          {required && <span className="text-rose-500 ml-1">*</span>}
        </label>
        {sublabel && <span className="text-xs text-stone-500">{sublabel}</span>}
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1 sm:gap-1.5" onMouseLeave={() => setHovered(null)}>
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => onChange(star)}
              onMouseEnter={() => setHovered(star)}
              className="p-1 sm:p-1.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-lg transition-transform hover:scale-110 active:scale-95"
              aria-label={`Beri nilai ${star} dari 5`}
            >
              <Star
                className={`w-6 h-6 sm:w-7 sm:h-7 transition-colors ${
                  star <= activeScore
                    ? 'fill-amber-400 text-amber-500'
                    : 'text-stone-300 stroke-[1.5]'
                }`}
              />
            </button>
          ))}
        </div>

        <div className="min-h-[20px] flex items-center">
          {activeScore > 0 ? (
            <span
              className={`text-xs font-semibold px-2.5 py-1 rounded-md transition-colors ${
                activeScore <= 2
                  ? 'bg-rose-100 text-rose-800'
                  : activeScore === 3
                  ? 'bg-amber-100 text-amber-900'
                  : 'bg-emerald-100 text-emerald-900'
              }`}
            >
              {activeScore}/5 · {descriptions[activeScore] || ''}
            </span>
          ) : (
            <span className="text-xs text-stone-400 italic">Pilih bintang 1 - 5</span>
          )}
        </div>
      </div>
    </div>
  );
};
