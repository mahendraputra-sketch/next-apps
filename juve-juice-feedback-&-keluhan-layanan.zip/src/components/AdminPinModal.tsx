import React, { useState } from 'react';
import {
  Lock,
  KeyRound,
  X,
  AlertCircle,
  CheckCircle2,
  ShieldCheck,
  Eye,
  EyeOff,
} from 'lucide-react';
import { User } from 'firebase/auth';

interface AdminPinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUnlock: () => void;
  user: User | null;
  onGoogleLogin?: () => void;
}

const PIN_STORAGE_KEY = 'juve_juice_admin_pin';
const DEFAULT_PIN = '1234';

export function getAdminPin(): string {
  try {
    return localStorage.getItem(PIN_STORAGE_KEY) || DEFAULT_PIN;
  } catch {
    return DEFAULT_PIN;
  }
}

export function saveAdminPin(newPin: string) {
  try {
    localStorage.setItem(PIN_STORAGE_KEY, newPin);
  } catch (e) {
    console.error(e);
  }
}

export const AdminPinModal: React.FC<AdminPinModalProps> = ({
  isOpen,
  onClose,
  onUnlock,
  user,
  onGoogleLogin,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isChangingPin, setIsChangingPin] = useState(false);
  const [newPinInput, setNewPinInput] = useState('');
  const [pinSuccessMsg, setPinSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentPin = getAdminPin();

  const handleVerifyPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === currentPin) {
      setErrorMsg(null);
      setPinInput('');
      onUnlock();
      onClose();
    } else {
      setErrorMsg('PIN yang Anda masukkan salah. Silakan coba lagi.');
    }
  };

  const handleChangePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPinInput.length < 4) {
      setErrorMsg('PIN minimal harus 4 digit angka.');
      return;
    }
    saveAdminPin(newPinInput);
    setPinSuccessMsg(`PIN baru berhasil disimpan: ${newPinInput}`);
    setIsChangingPin(false);
    setNewPinInput('');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl border border-stone-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-stone-900 text-base leading-tight">
                Akses Pemilik &amp; Admin
              </h3>
              <p className="text-[11px] text-stone-500">Khusus pengelola stand JUVE JUICE</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          <p className="text-xs text-stone-600 leading-relaxed">
            Halaman rekap data, keluhan pelanggan, dan evaluasi pegawai dilindungi agar <strong>tidak dapat diakses oleh pelanggan umum</strong>.
          </p>

          {!isChangingPin ? (
            <form onSubmit={handleVerifyPin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Masukkan PIN Pengelola
                </label>
                <div className="relative">
                  <input
                    type={showPin ? 'text' : 'password'}
                    maxLength={8}
                    value={pinInput}
                    onChange={(e) => {
                      setPinInput(e.target.value);
                      setErrorMsg(null);
                    }}
                    placeholder="Masukkan PIN"
                    autoFocus
                    className="w-full pl-4 pr-10 py-3 text-center tracking-widest text-lg font-mono font-bold bg-stone-50 border border-stone-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPin(!showPin)}
                    className="absolute right-3 top-3.5 text-stone-400 hover:text-stone-700"
                  >
                    {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <div className="flex justify-end items-center mt-1.5 text-[11px]">
                  <button
                    type="button"
                    onClick={() => {
                      setIsChangingPin(true);
                      setErrorMsg(null);
                    }}
                    className="text-amber-700 font-semibold hover:underline"
                  >
                    Ubah PIN Pengelola
                  </button>
                </div>
              </div>

              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2 text-xs text-rose-800">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {pinSuccessMsg && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{pinSuccessMsg}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={!pinInput.trim()}
                className="w-full py-3 px-4 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-sm font-bold shadow-xs transition-colors disabled:opacity-50"
              >
                Buka Dashboard Admin
              </button>
            </form>
          ) : (
            <form onSubmit={handleChangePin} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Atur PIN Baru (4-6 Angka)
                </label>
                <input
                  type="password"
                  maxLength={6}
                  value={newPinInput}
                  onChange={(e) => setNewPinInput(e.target.value)}
                  placeholder="Contoh: 5678"
                  autoFocus
                  className="w-full px-3 py-2 text-center text-lg font-mono font-bold bg-stone-50 border border-stone-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              {errorMsg && (
                <p className="text-xs text-rose-600">{errorMsg}</p>
              )}

              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsChangingPin(false)}
                  className="flex-1 py-2 text-xs font-semibold text-stone-600 bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={newPinInput.length < 4}
                  className="flex-1 py-2 text-xs font-bold text-white bg-amber-500 hover:bg-amber-600 rounded-xl disabled:opacity-50"
                >
                  Simpan PIN
                </button>
              </div>
            </form>
          )}

          {/* Quick Google Sign In bypass if user is logged in */}
          {user && (
            <div className="pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => {
                  onUnlock();
                  onClose();
                }}
                className="w-full flex items-center justify-center gap-2 py-2 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition-colors"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Masuk Cepat via Akun Google ({user.email?.split('@')[0]})</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
