import React, { useState } from 'react';
import {
  X,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  PlusCircle,
  RefreshCw,
  FolderOpen,
  Info,
} from 'lucide-react';
import { User } from 'firebase/auth';
import { SheetsConfig } from '../types/feedback';
import { createJuveSpreadsheet, verifySpreadsheet } from '../lib/sheets';

interface SheetsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  accessToken: string | null;
  sheetsConfig: SheetsConfig | null;
  onSaveConfig: (config: SheetsConfig | null) => void;
  onLogin: () => Promise<void>;
  isLoggingIn: boolean;
}

export const SheetsModal: React.FC<SheetsModalProps> = ({
  isOpen,
  onClose,
  user,
  accessToken,
  sheetsConfig,
  onSaveConfig,
  onLogin,
  isLoggingIn,
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'existing'>('create');
  const [customTitle, setCustomTitle] = useState(
    'JUVE JUICE - Rekap Evaluasi & Keluhan Pelanggan (The Taman Dayu)'
  );
  const [existingInput, setExistingInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // Extract ID if user pastes full URL
  const parseSpreadsheetId = (input: string): string => {
    const trimmed = input.trim();
    const match = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (match && match[1]) {
      return match[1];
    }
    return trimmed;
  };

  const handleCreateNewSheet = async () => {
    if (!accessToken) {
      setErrorMessage('Silakan login dengan Google terlebih dahulu.');
      return;
    }

    setLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const result = await createJuveSpreadsheet(accessToken, customTitle);
      const newConfig: SheetsConfig = {
        spreadsheetId: result.spreadsheetId,
        spreadsheetUrl: result.spreadsheetUrl,
        spreadsheetTitle: result.title,
        lastSyncedAt: new Date().toISOString(),
      };
      onSaveConfig(newConfig);
      setSuccessMessage('Spreadsheet baru berhasil dibuat dan langsung terhubung!');
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Gagal membuat spreadsheet baru.');
    } finally {
      setLoading(false);
    }
  };

  const handleConnectExisting = async () => {
    if (!accessToken) {
      setErrorMessage('Silakan login dengan Google terlebih dahulu.');
      return;
    }

    const sheetId = parseSpreadsheetId(existingInput);
    if (!sheetId) {
      setErrorMessage('Masukkan ID Spreadsheet atau link Google Sheets yang valid.');
      return;
    }

    setLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const verified = await verifySpreadsheet(accessToken, sheetId);
      const newConfig: SheetsConfig = {
        spreadsheetId: sheetId,
        spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
        spreadsheetTitle: verified.title,
        lastSyncedAt: new Date().toISOString(),
      };
      onSaveConfig(newConfig);
      setSuccessMessage(`Berhasil menghubungkan ke spreadsheet "${verified.title}"!`);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(
        err.message || 'Gagal memverifikasi spreadsheet. Pastikan Anda memiliki izin akses.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = () => {
    if (window.confirm('Putuskan koneksi ke Google Spreadsheet saat ini?')) {
      onSaveConfig(null);
      setSuccessMessage('Koneksi spreadsheet telah diputuskan.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-stone-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-stone-900">
                Integrasi Google Sheets
              </h2>
              <p className="text-xs text-stone-500">
                Penyimpanan otomatis formulir evaluasi & keluhan JUVE JUICE
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Step 1: Authentication */}
          <div className="p-4 rounded-xl bg-stone-50 border border-stone-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-stone-500">
                  Status Akun Google
                </p>
                {user ? (
                  <div className="mt-1 flex items-center gap-2">
                    <span className="text-sm font-medium text-stone-900">
                      {user.displayName || user.email}
                    </span>
                    <span className="inline-flex items-center text-xs font-medium text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                      Terhubung
                    </span>
                  </div>
                ) : (
                  <p className="text-sm text-stone-600 mt-1">
                    Masuk dengan akun Google untuk mengaktifkan sinkronisasi ke spreadsheet Anda.
                  </p>
                )}
              </div>

              {!user && (
                <button
                  type="button"
                  onClick={onLogin}
                  disabled={isLoggingIn}
                  className="flex items-center gap-2.5 px-4 py-2 bg-white hover:bg-stone-50 text-stone-700 border border-stone-300 rounded-lg shadow-xs text-sm font-medium transition-all disabled:opacity-50"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.87c2.26-2.09 3.67-5.17 3.67-9.15z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.87-3.05c-1.08.72-2.45 1.16-4.06 1.16-3.13 0-5.78-2.11-6.73-4.96H1.26v3.15C3.25 21.31 7.31 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.27 14.24A7.18 7.18 0 0 1 4.89 12c0-.78.14-1.53.38-2.24V6.61H1.26A11.95 11.95 0 0 0 0 12c0 1.92.45 3.74 1.26 5.39l4.01-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.25 2.69 1.26 6.61l4.01 3.15c.95-2.85 3.6-4.96 6.73-4.96z"
                    />
                  </svg>
                  <span>{isLoggingIn ? 'Menghubungkan...' : 'Masuk dengan Google'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Active Configuration Overview */}
          {sheetsConfig && (
            <div className="p-4 rounded-xl bg-emerald-50/80 border border-emerald-200">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800 uppercase tracking-wider">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Spreadsheet Aktif</span>
                  </div>
                  <h3 className="font-bold text-stone-900 text-base">
                    {sheetsConfig.spreadsheetTitle}
                  </h3>
                  <p className="text-xs text-stone-500 font-mono">
                    ID: {sheetsConfig.spreadsheetId}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={sheetsConfig.spreadsheetUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-800 bg-white hover:bg-emerald-100 rounded-lg border border-emerald-300 transition-colors shadow-xs"
                  >
                    <span>Buka Sheet</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <button
                    onClick={handleDisconnect}
                    className="px-2.5 py-1.5 text-xs font-medium text-rose-700 hover:bg-rose-100 rounded-lg transition-colors"
                  >
                    Putuskan
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Mode Tabs */}
          {user && (
            <div className="space-y-4">
              <div className="flex items-center p-1 bg-stone-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => setActiveTab('create')}
                  className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-lg transition-all ${
                    activeTab === 'create'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <PlusCircle className="w-4 h-4 text-amber-600" />
                  <span>Buat Spreadsheet Baru</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('existing')}
                  className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-lg transition-all ${
                    activeTab === 'existing'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <FolderOpen className="w-4 h-4 text-emerald-600" />
                  <span>Tautkan Sheet yang Ada</span>
                </button>
              </div>

              {activeTab === 'create' ? (
                <div className="space-y-3">
                  <label className="block text-xs font-semibold text-stone-700">
                    Judul Spreadsheet Baru
                  </label>
                  <input
                    type="text"
                    value={customTitle}
                    onChange={(e) => setCustomTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition-all"
                    placeholder="Contoh: JUVE JUICE - Rekap Evaluasi & Keluhan Pelanggan"
                  />
                  <div className="flex items-start gap-2 p-3 bg-amber-50/60 rounded-xl border border-amber-200/80 text-xs text-amber-900">
                    <Info className="w-4 h-4 shrink-0 text-amber-700 mt-0.5" />
                    <p>
                      Sistem akan membuat file spreadsheet baru di Google Drive Anda lengkap dengan
                      19 kolom terstruktur (ID, Waktu, Pelanggan, Rating 5 Dimensi, Kategori Keluhan,
                      dan Status Penanganan).
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleCreateNewSheet}
                    disabled={loading || !customTitle}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold shadow-xs transition-colors disabled:opacity-50"
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Sedang Menyiapkan Sheet...</span>
                      </>
                    ) : (
                      <>
                        <PlusCircle className="w-4 h-4" />
                        <span>Buat &amp; Hubungkan Spreadsheet Sekarang</span>
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <label className="block text-xs font-semibold text-stone-700">
                    Link atau ID Spreadsheet
                  </label>
                  <input
                    type="text"
                    value={existingInput}
                    onChange={(e) => setExistingInput(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    placeholder="https://docs.google.com/spreadsheets/d/1aBcD.../edit atau ID sheet"
                  />
                  <p className="text-xs text-stone-500">
                    Pastikan akun Google Anda memiliki akses edit pada file spreadsheet tersebut.
                  </p>
                  <button
                    type="button"
                    onClick={handleConnectExisting}
                    disabled={loading || !existingInput.trim()}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold shadow-xs transition-colors disabled:opacity-50"
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Memverifikasi Akses Sheet...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Hubungkan ke Sheet Ini</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Feedback messages */}
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs font-medium text-rose-800">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs font-medium text-emerald-800">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successMessage}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-stone-50 border-t border-stone-100 flex items-center justify-between">
          <p className="text-[11px] text-stone-500">
            Izin hanya digunakan untuk menambahkan baris data evaluasi JUVE JUICE.
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-700 hover:text-stone-900 bg-white hover:bg-stone-100 border border-stone-200 rounded-lg transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
