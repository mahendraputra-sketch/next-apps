import React, { useState, useRef } from 'react';
import {
  Send,
  Camera,
  Upload,
  X,
  Star,
  CheckCircle,
  FileSpreadsheet,
  RotateCcw,
  Sparkles,
  MapPin,
  Image as ImageIcon,
} from 'lucide-react';
import {
  FeedbackSubmission,
  JUVE_MENU_CATEGORIES,
  SheetsConfig,
} from '../types/feedback';

interface CustomerFormProps {
  onSubmit: (submission: FeedbackSubmission) => Promise<{ success: boolean; synced: boolean; error?: string }>;
  sheetsConfig: SheetsConfig | null;
}

export const CustomerForm: React.FC<CustomerFormProps> = ({ onSubmit, sheetsConfig }) => {
  // Category & Menu selection
  const [selectedCategory, setSelectedCategory] = useState<string>('Jus Buah');
  const [selectedMenuItem, setSelectedMenuItem] = useState<string>('Juice Alpukat: Rp 15.000');

  // Customer simple fields
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [tableOrOrderNo, setTableOrOrderNo] = useState('');
  const [staffNameOrShift, setStaffNameOrShift] = useState('');

  // Rating (1 - 5 stars)
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);

  // Complaint / Feedback
  const [complaintText, setComplaintText] = useState('');

  // Optional Photo Upload
  const [photoDataUrl, setPhotoDataUrl] = useState<string | null>(null);
  const [photoFileName, setPhotoFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // UI state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedItem, setSubmittedItem] = useState<FeedbackSubmission | null>(null);
  const [syncStatus, setSyncStatus] = useState<{ synced: boolean; error?: string } | null>(null);

  const activeCategoryData = JUVE_MENU_CATEGORIES.find(
    (c) => c.category === selectedCategory
  );

  // Handle photo file selection with lightweight resizing/compression
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setPhotoFileName(file.name);

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Resize to maximum 800px width/height for fast handling and lightweight storage
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        const maxDim = 800;

        if (width > height && width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.7);
          setPhotoDataUrl(compressedDataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleRemovePhoto = () => {
    setPhotoDataUrl(null);
    setPhotoFileName('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const submissionId = `JJ-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newFeedback: FeedbackSubmission = {
      id: submissionId,
      createdAt: new Date().toISOString(),
      customerName: customerName.trim() || 'Pelanggan (Anonim)',
      customerPhone: customerPhone.trim() || '',
      tableOrOrderNo: tableOrOrderNo.trim() || '-',
      menuCategory: selectedCategory,
      menuItem: selectedMenuItem,
      staffNameOrShift: staffNameOrShift.trim() || undefined,
      rating,
      complaintOrFeedback: complaintText.trim() || 'Pelayanan memuaskan, tidak ada keluhan khusus.',
      photoUrl: photoDataUrl || undefined,
      status: 'baru',
    };

    setIsSubmitting(true);
    try {
      const res = await onSubmit(newFeedback);
      setSubmittedItem(newFeedback);
      setSyncStatus({ synced: res.synced, error: res.error });
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setSubmittedItem(null);
    setSyncStatus(null);
    setCustomerName('');
    setCustomerPhone('');
    setTableOrOrderNo('');
    setStaffNameOrShift('');
    setComplaintText('');
    setPhotoDataUrl(null);
    setPhotoFileName('');
    setRating(5);
  };

  const ratingDescriptions: Record<number, string> = {
    1: 'Sangat Kecewa',
    2: 'Kurang Puas',
    3: 'Cukup / Standar',
    4: 'Puas & Enak',
    5: 'Sangat Puas & Rekomendasi!',
  };

  const currentScore = hoverRating ?? rating;

  // Thank You / Success View
  if (submittedItem) {
    return (
      <div className="max-w-xl mx-auto px-4 py-8">
        <div className="bg-white rounded-3xl shadow-xl border border-stone-200 overflow-hidden">
          <div className="bg-amber-500 p-8 text-center text-white">
            <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-3 border border-white/30">
              <CheckCircle className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-black tracking-tight">Terima Kasih Banyak!</h2>
            <p className="text-amber-100 text-xs sm:text-sm mt-1 max-w-sm mx-auto">
              Masukan Anda telah kami terima untuk peningkatan layanan JUVE JUICE di New Food Terrace.
            </p>
          </div>

          <div className="p-6 space-y-5">
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-2">
              <div className="flex justify-between items-center border-b border-stone-200 pb-2">
                <span className="text-stone-500">Nomor Masukan:</span>
                <span className="font-mono font-bold text-stone-900 text-sm">{submittedItem.id}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-stone-500">Menu Dipesan:</span>
                <span className="font-semibold text-stone-800">{submittedItem.menuItem}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-stone-500">Penilaian:</span>
                <span className="font-bold text-amber-600">{submittedItem.rating} / 5 Bintang</span>
              </div>
              {submittedItem.photoUrl && (
                <div className="flex justify-between items-center text-emerald-700 font-medium">
                  <span>Foto Bukti:</span>
                  <span>Terlampir (1 Foto)</span>
                </div>
              )}
            </div>

            {syncStatus?.synced ? (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-800">
                <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Otomatis tercatat di Google Spreadsheet pengelola stand.</span>
              </div>
            ) : (
              <div className="p-3 bg-stone-100 rounded-xl text-xs text-stone-600">
                Data tersimpan di sistem stand JUVE JUICE.
              </div>
            )}

            <button
              onClick={handleReset}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-sm font-semibold transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Isi Form Masukan Baru</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 sm:py-8">
      {/* Brand Header */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200 mb-6">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-700">
              <MapPin className="w-3.5 h-3.5" />
              <span>New Food Terrace · The Taman Dayu</span>
            </div>
            <h1 className="text-2xl font-black text-stone-900 tracking-tight">
              JUVE JUICE
            </h1>
            <p className="text-xs text-stone-500 leading-relaxed">
              Form penilaian &amp; keluhan pelayanan pelanggan. Masukan Anda langsung tersimpan ke rekap Spreadsheet pengelola stand.
            </p>
          </div>

          <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white font-black text-2xl flex items-center justify-center shrink-0 shadow-md">
            J
          </div>
        </div>
      </div>

      {/* Main Form */}
      <form
        onSubmit={handleSubmit}
        className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-stone-200 space-y-6"
      >
        {/* 1. Identitas Pelanggan (Cukup & Simpel) */}
        <div className="space-y-3">
          <h2 className="text-sm font-bold uppercase tracking-wider text-stone-500">
            1. Data Pelanggan (Bisa Dikosongkan / Anonim)
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Nama Anda (Opsional)
              </label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="Contoh: Bima (kosongkan jika anonim)"
                className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                No. WhatsApp (Opsional)
              </label>
              <input
                type="tel"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="0812xxxx (untuk tindak lanjut)"
                className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Nomor Meja atau Nomor Nota
            </label>
            <input
              type="text"
              value={tableOrOrderNo}
              onChange={(e) => setTableOrOrderNo(e.target.value)}
              placeholder="Contoh: Meja 12 Food Terrace atau Order #034"
              className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none transition-all"
            />
          </div>
        </div>

        {/* 2. Pilihan Menu JUVE JUICE Sesuai Daftar */}
        <div className="space-y-3 pt-3 border-t border-stone-100">
          <h2 className="text-sm font-bold uppercase tracking-wider text-stone-500">
            2. Menu yang Dipesan
          </h2>

          {/* Category Tabs: Jus Buah, Jus Sehat Mix, Boba */}
          <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-xl">
            {JUVE_MENU_CATEGORIES.map((cat) => (
              <button
                key={cat.category}
                type="button"
                onClick={() => {
                  setSelectedCategory(cat.category);
                  const firstAvail = cat.items.find((i) => i.available) || cat.items[0];
                  setSelectedMenuItem(
                    `${firstAvail.name}: Rp ${firstAvail.price.toLocaleString('id-ID')}`
                  );
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                  selectedCategory === cat.category
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {cat.category}
              </button>
            ))}
          </div>

          {/* Menu Dropdown / Selector with Prices & Availability */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1.5">
              Pilih Minuman ({selectedCategory})
            </label>
            <select
              value={selectedMenuItem}
              onChange={(e) => setSelectedMenuItem(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none transition-all font-medium text-stone-800"
            >
              {activeCategoryData?.items.map((item) => (
                <option
                  key={item.name}
                  value={`${item.name}: Rp ${item.price.toLocaleString('id-ID')}`}
                >
                  {item.name} - Rp {item.price.toLocaleString('id-ID')}{' '}
                  {item.available ? '(Tersedia)' : '(Habis)'}
                </option>
              ))}
            </select>
          </div>

          {/* Staf / Pegawai yang Melayani */}
          <div className="pt-1">
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-stone-700">
                Pegawai / Staf yang Melayani (Opsional)
              </label>
              <span className="text-[11px] text-amber-700 font-medium">
                Membantu pemilik mengevaluasi kinerja staf
              </span>
            </div>
            <input
              type="text"
              value={staffNameOrShift}
              onChange={(e) => setStaffNameOrShift(e.target.value)}
              placeholder="Nama di nametag/nota, atau ciri staf (cth: Barista kacamata / Kasir pria)"
              className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none transition-all placeholder:text-stone-400"
            />
            <div className="flex flex-wrap items-center gap-1.5 mt-2">
              <span className="text-[10px] text-stone-400 font-medium">Pilihan cepat:</span>
              {[
                'Shift Pagi (10:00 - 16:00)',
                'Shift Malam (16:00 - 22:00)',
                'Staf Kasir',
                'Barista Pembuat Jus',
              ].map((chip) => (
                <button
                  key={chip}
                  type="button"
                  onClick={() => setStaffNameOrShift(chip)}
                  className="text-[11px] px-2.5 py-0.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg transition-colors border border-stone-200"
                >
                  {chip}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 3. Penilaian Layanan (1-5 Bintang) */}
        <div className="space-y-3 pt-3 border-t border-stone-100">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-stone-500">
              3. Penilaian Layanan
            </h2>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900">
              {currentScore}/5 · {ratingDescriptions[currentScore]}
            </span>
          </div>

          <div
            className="flex items-center justify-center gap-2 py-2"
            onMouseLeave={() => setHoverRating(null)}
          >
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoverRating(star)}
                className="p-1 focus:outline-none transition-transform hover:scale-125 active:scale-95"
                aria-label={`Beri bintang ${star}`}
              >
                <Star
                  className={`w-9 h-9 sm:w-10 sm:h-10 transition-colors ${
                    star <= currentScore
                      ? 'fill-amber-400 text-amber-500'
                      : 'text-stone-300 stroke-[1.5]'
                  }`}
                />
              </button>
            ))}
          </div>
        </div>

        {/* 4. Keluhan / Masukan Pelayanan */}
        <div className="space-y-2 pt-3 border-t border-stone-100">
          <h2 className="text-sm font-bold uppercase tracking-wider text-stone-500">
            4. Keluhan / Catatan Saat Dilayani
          </h2>
          <p className="text-xs text-stone-500">
            Ceritakan keluhan atau kendala (misal: waktu tunggu lama, rasa kurang pas, salah pesanan, atau keramahan staf).
          </p>

          <textarea
            rows={3}
            value={complaintText}
            onChange={(e) => setComplaintText(e.target.value)}
            placeholder="Tuliskan keluhan atau saran Anda di sini..."
            className="w-full p-3.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none transition-all placeholder:text-stone-400"
          />
        </div>

        {/* 5. Menu Upload Foto / Bukti (Opsional) */}
        <div className="space-y-3 pt-3 border-t border-stone-100">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-stone-500">
              5. Foto / Bukti Minuman (Opsional)
            </h2>
            <span className="text-[11px] text-stone-400">Bisa foto cup / struk nota</span>
          </div>

          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            capture="environment"
            onChange={handlePhotoUpload}
            className="hidden"
          />

          {!photoDataUrl ? (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex flex-col items-center justify-center p-4 border-2 border-dashed border-stone-200 hover:border-amber-400 bg-stone-50/70 hover:bg-amber-50/40 rounded-2xl transition-all text-center group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-stone-500 group-hover:text-amber-600 group-hover:scale-110 shadow-xs transition-all mb-2">
                <Camera className="w-5 h-5" />
              </div>
              <p className="text-xs font-bold text-stone-800">
                Ambil Foto atau Unggah dari Galeri
              </p>
              <p className="text-[11px] text-stone-400 mt-0.5">
                Format JPG/PNG, ukuran otomatis dioptimalkan
              </p>
            </button>
          ) : (
            <div className="relative rounded-2xl overflow-hidden border border-stone-200 bg-stone-100 p-2 flex items-center gap-3">
              <img
                src={photoDataUrl}
                alt="Foto Bukti Minuman"
                className="w-20 h-20 object-cover rounded-xl border border-stone-200 shadow-xs"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 text-xs font-bold text-stone-800">
                  <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="truncate">{photoFileName || 'Foto Bukti Terlampir'}</span>
                </div>
                <p className="text-[11px] text-emerald-600 font-medium mt-0.5">
                  Foto siap dikirim bersama formulir
                </p>
              </div>
              <button
                type="button"
                onClick={handleRemovePhoto}
                className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                title="Hapus foto"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2 py-3.5 px-6 bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-white rounded-2xl text-base font-bold shadow-md hover:shadow-lg transition-all disabled:opacity-50"
          >
            {isSubmitting ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Menyimpan ke Spreadsheet...</span>
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                <span>Kirim Penilaian &amp; Keluhan</span>
              </>
            )}
          </button>
          <p className="text-center text-[11px] text-stone-400 mt-2">
            Terima kasih atas masukan Anda untuk JUVE JUICE di New Food Terrace The Taman Dayu.
          </p>
        </div>
      </form>
    </div>
  );
};
