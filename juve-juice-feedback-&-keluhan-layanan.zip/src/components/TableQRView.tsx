import React, { useEffect, useState, useRef } from 'react';
import QRCode from 'qrcode';
import {
  QrCode,
  Download,
  Printer,
  Sparkles,
  MapPin,
  CheckCircle,
  Copy,
  ExternalLink,
} from 'lucide-react';

interface TableQRViewProps {
  onBackToCustomer: () => void;
}

export const TableQRView: React.FC<TableQRViewProps> = ({ onBackToCustomer }) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  // App URL for the QR Code (Points strictly to clean customer form)
  const currentAppUrl = window.location.origin + window.location.pathname;

  useEffect(() => {
    QRCode.toDataURL(currentAppUrl, {
      width: 400,
      margin: 2,
      color: {
        dark: '#1c1917', // stone-900
        light: '#ffffff',
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error('Error generating QR:', err));
  }, [currentAppUrl]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentAppUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = 'QR-JUVE-JUICE-Taman-Dayu.png';
    a.click();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700 uppercase tracking-wider">
            <span>Standee Meja &amp; Kasir</span>
            <span>·</span>
            <span>New Food Terrace The Taman Dayu</span>
          </div>
          <h1 className="text-2xl font-black text-stone-900 tracking-tight mt-0.5">
            QR Code Formulir Pelanggan
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Cetak dan letakkan di akrilik meja makan Food Terrace agar pelanggan dapat langsung menyampaikan masukan &amp; keluhan.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyLink}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-700 bg-white hover:bg-stone-50 border border-stone-200 rounded-xl transition-colors shadow-xs"
          >
            {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Tersalin!' : 'Salin Tautan'}</span>
          </button>
          <button
            onClick={handleDownload}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-700 bg-white hover:bg-stone-50 border border-stone-200 rounded-xl transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Unduh QR</span>
          </button>
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-amber-500 hover:bg-amber-600 rounded-xl transition-colors shadow-xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak Standee</span>
          </button>
        </div>
      </div>

      {/* Printable Standee Preview Card */}
      <div className="flex justify-center">
        <div
          ref={printRef}
          className="w-full max-w-sm bg-white rounded-3xl p-8 border-2 border-stone-200 shadow-xl text-center space-y-6 print:m-0 print:border-none print:shadow-none"
        >
          {/* Stand Logo & Location */}
          <div className="space-y-1">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white font-black text-2xl flex items-center justify-center mx-auto shadow-md">
              J
            </div>
            <h2 className="text-xl font-black text-stone-900 tracking-tight">
              JUVE JUICE
            </h2>
            <div className="inline-flex items-center gap-1 text-xs font-medium text-stone-600 bg-stone-100 px-2.5 py-0.5 rounded-full">
              <MapPin className="w-3 h-3 text-amber-600" />
              <span>New Food Terrace · The Taman Dayu</span>
            </div>
          </div>

          {/* QR Code Container */}
          <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200 inline-block shadow-inner">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt="QR Code JUVE JUICE"
                className="w-48 h-48 mx-auto rounded-lg"
              />
            ) : (
              <div className="w-48 h-48 flex items-center justify-center bg-stone-200 rounded-lg animate-pulse text-stone-400 text-xs">
                Membuat QR Code...
              </div>
            )}
          </div>

          {/* Call to action message */}
          <div className="space-y-1.5">
            <p className="text-sm font-extrabold text-stone-900">
              Pindai untuk Penilaian &amp; Keluhan Layanan
            </p>
            <p className="text-xs text-stone-500 leading-relaxed max-w-[260px] mx-auto">
              Ada kendala dengan jus Anda atau antrean lama? Sampaikan langsung kepada kami demi pelayanan terbaik!
            </p>
          </div>

          <div className="pt-2 border-t border-stone-100 flex items-center justify-center gap-2 text-[10px] text-stone-600 font-medium">
            <span>Terhubung Langsung ke Sistem Google Sheets</span>
          </div>
        </div>
      </div>
    </div>
  );
};
