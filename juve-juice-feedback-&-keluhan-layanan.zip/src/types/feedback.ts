export interface MenuItem {
  name: string;
  price: number;
  available: boolean;
  category: 'Jus Buah' | 'Jus Sehat Mix' | 'Boba';
}

export const JUVE_MENU_CATEGORIES = [
  {
    category: 'Jus Buah',
    items: [
      { name: 'Juice Jeruk', price: 8000, available: true },
      { name: 'Juice Nanas', price: 10000, available: true },
      { name: 'Juice Wortel', price: 10000, available: true },
      { name: 'Juice Apel', price: 10000, available: true },
      { name: 'Juice Jambu', price: 10000, available: true },
      { name: 'Juice Leci', price: 10000, available: true },
      { name: 'Juice Lemon', price: 10000, available: true },
      { name: 'Juice Mangga', price: 10000, available: true },
      { name: 'Juice Melon', price: 10000, available: true },
      { name: 'Juice Naga', price: 10000, available: true },
      { name: 'Juice Pisang', price: 10000, available: true },
      { name: 'Juice Semangka', price: 10000, available: true },
      { name: 'Juice Tomat', price: 10000, available: true },
      { name: 'Juice Alpukat', price: 15000, available: true },
      { name: 'Juice Anggur', price: 10000, available: false },
      { name: 'Juice Durian', price: 15000, available: false },
      { name: 'Juice Kiwi', price: 10000, available: false },
      { name: 'Juice Tape', price: 10000, available: false },
    ],
  },
  {
    category: 'Jus Sehat Mix',
    items: [
      { name: 'Alpukat + Pisang', price: 15000, available: true },
      { name: 'Jambu + Jeruk', price: 15000, available: true },
      { name: 'Lemon + Nanas', price: 15000, available: true },
      { name: 'Mangga + Stroberi', price: 15000, available: true },
      { name: 'Melon + Pisang', price: 15000, available: true },
      { name: 'Nanas + Pisang', price: 15000, available: true },
      { name: 'Pisang + Stroberi', price: 15000, available: true },
      { name: 'Semangka + Stroberi', price: 15000, available: true },
      { name: 'Wortel + Tomat', price: 15000, available: true },
      { name: 'Wortel + Tomat + Apel', price: 20000, available: true },
    ],
  },
  {
    category: 'Boba',
    items: [
      { name: 'Arome Oreo Brown Sugar', price: 15000, available: true },
      { name: 'Arome Regal Brown Sugar', price: 15000, available: true },
      { name: 'Chocolate', price: 15000, available: true },
      { name: 'Jasmine Milk Tea', price: 15000, available: true },
      { name: 'Matcha Latte', price: 15000, available: true },
      { name: 'Mocca', price: 15000, available: true },
      { name: 'Oreo Regal Milk Boba Sugar', price: 15000, available: true },
      { name: 'Pinky Love', price: 15000, available: true },
      { name: 'Redvelvet', price: 15000, available: true },
      { name: 'Salted Sugar Caramel', price: 15000, available: true },
      { name: 'Sweet Purple', price: 15000, available: true },
    ],
  },
] as const;

export interface FeedbackSubmission {
  id: string;
  createdAt: string;
  customerName: string;
  customerPhone?: string;
  tableOrOrderNo?: string;
  menuCategory: string;
  menuItem: string;
  staffNameOrShift?: string; // Nama atau shift pegawai yang melayani
  rating: number; // 1 to 5 stars
  complaintOrFeedback: string;
  photoUrl?: string; // Optional uploaded image (data url)
  status: 'baru' | 'diproses' | 'selesai';
  internalNotes?: string;
  resolvedAt?: string;
  syncedToSheets?: boolean;
}

export interface SheetsConfig {
  spreadsheetId: string;
  spreadsheetUrl: string;
  spreadsheetTitle: string;
  lastSyncedAt?: string;
}
