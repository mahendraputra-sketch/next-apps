import { FeedbackSubmission } from '../types/feedback';

export const DEFAULT_SHEET_TITLE =
  'JUVE JUICE - Penilaian & Keluhan Pelanggan (New Food Terrace Taman Dayu)';

export const SHEET_HEADERS = [
  'ID Evaluasi',
  'Waktu Pengisian',
  'Nama Pelanggan',
  'No. WhatsApp',
  'No. Meja / Order',
  'Kategori Menu',
  'Menu Dipesan',
  'Pegawai / Shift Melayani',
  'Rating Layanan (1-5)',
  'Keluhan / Masukan Pelanggan',
  'Ada Foto Bukti?',
  'Status Penanganan',
  'Catatan Internal Stand',
];

/**
 * Get the name of the first tab/sheet from a spreadsheet to avoid assuming "Sheet1"
 */
export async function getFirstSheetName(
  accessToken: string,
  spreadsheetId: string
): Promise<string> {
  try {
    const res = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties.title`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(
        err.error?.message || `Gagal membaca informasi spreadsheet (HTTP ${res.status})`
      );
    }

    const data = await res.json();
    if (data.sheets && data.sheets.length > 0) {
      return data.sheets[0].properties.title;
    }
    return 'Sheet1';
  } catch (error) {
    console.warn('Fallback to Sheet1:', error);
    return 'Sheet1';
  }
}

/**
 * Creates a brand new Google Spreadsheet configured with JUVE JUICE headers
 */
export async function createJuveSpreadsheet(
  accessToken: string,
  customTitle?: string
): Promise<{ spreadsheetId: string; spreadsheetUrl: string; title: string }> {
  const title = customTitle || DEFAULT_SHEET_TITLE;

  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title,
      },
      sheets: [
        {
          properties: {
            title: 'Penilaian & Keluhan',
            gridProperties: {
              frozenRowCount: 1,
            },
          },
        },
      ],
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(
      errorData.error?.message ||
        `Gagal membuat spreadsheet baru (HTTP ${response.status})`
    );
  }

  const data = await response.json();
  const spreadsheetId = data.spreadsheetId;
  const spreadsheetUrl =
    data.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  await setSheetHeaders(accessToken, spreadsheetId, 'Penilaian & Keluhan');

  return {
    spreadsheetId,
    spreadsheetUrl,
    title,
  };
}

/**
 * Sets initial headers on a sheet
 */
export async function setSheetHeaders(
  accessToken: string,
  spreadsheetId: string,
  sheetName: string
) {
  const range = `'${sheetName}'!A1:M1`;

  const appendRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(
      range
    )}?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        range,
        majorDimension: 'ROWS',
        values: [SHEET_HEADERS],
      }),
    }
  );

  if (!appendRes.ok) {
    console.warn('Failed to set headers:', await appendRes.text());
  }
}

/**
 * Appends a customer review/complaint row to the spreadsheet
 */
export async function appendFeedbackToSheet(
  accessToken: string,
  spreadsheetId: string,
  item: FeedbackSubmission
): Promise<boolean> {
  const sheetName = await getFirstSheetName(accessToken, spreadsheetId);

  const rowValues = [
    item.id,
    new Date(item.createdAt).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta',
      dateStyle: 'medium',
      timeStyle: 'short',
    }),
    item.customerName || 'Pelanggan (Anonim)',
    item.customerPhone || '-',
    item.tableOrOrderNo || '-',
    item.menuCategory || 'Jus Buah',
    item.menuItem || '-',
    item.staffNameOrShift || '-',
    item.rating,
    item.complaintOrFeedback || '-',
    item.photoUrl ? 'Ada Foto (Terlampir)' : 'Tidak Ada',
    item.status.toUpperCase(),
    item.internalNotes || '-',
  ];

  const range = `'${sheetName}'!A:M`;
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(
    range
  )}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      range,
      majorDimension: 'ROWS',
      values: [rowValues],
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(
      errorData.error?.message ||
        `Gagal menyimpan baris ke spreadsheet (HTTP ${response.status})`
    );
  }

  return true;
}

/**
 * Check if a spreadsheet ID exists and is accessible
 */
export async function verifySpreadsheet(
  accessToken: string,
  spreadsheetId: string
): Promise<{ title: string; sheets: string[] }> {
  const res = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=properties.title,sheets.properties.title`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    }
  );

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(
      err.error?.message || 'Spreadsheet tidak ditemukan atau Anda tidak memiliki izin akses.'
    );
  }

  const data = await res.json();
  const sheets = (data.sheets || []).map((s: any) => s.properties?.title || 'Sheet1');
  return {
    title: data.properties?.title || 'Google Sheet',
    sheets,
  };
}
