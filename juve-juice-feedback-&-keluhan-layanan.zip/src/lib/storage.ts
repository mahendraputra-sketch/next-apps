import { FeedbackSubmission, SheetsConfig } from '../types/feedback';

const STORAGE_KEY = 'juve_juice_evaluations';
const CONFIG_KEY = 'juve_juice_sheets_config';

const INITIAL_SAMPLES: FeedbackSubmission[] = [
  {
    id: 'JJ-2026-001',
    createdAt: new Date(Date.now() - 3600000 * 2.5).toISOString(),
    customerName: 'Bima Santoso',
    customerPhone: '081234567890',
    tableOrOrderNo: 'Meja 14 (Food Terrace)',
    menuCategory: 'Jus Buah',
    menuItem: 'Juice Alpukat (Rp 15.000)',
    staffNameOrShift: 'Rian (Shift Malam)',
    rating: 2,
    complaintOrFeedback:
      'Waktu tunggu pembuatan jus alpukat memakan waktu 25 menit. Saat itu kasir tidak memberi tahu kalau blender sedang antre panjang.',
    status: 'diproses',
    internalNotes: 'Sudah dievaluasi ke barista agar selalu memberi estimasi waktu tunggu.',
    syncedToSheets: true,
  },
  {
    id: 'JJ-2026-002',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    customerName: 'Dewi Rahma',
    customerPhone: '085799123456',
    tableOrOrderNo: 'Order #042',
    menuCategory: 'Jus Sehat Mix',
    menuItem: 'Mangga + Stroberi (Rp 15.000)',
    staffNameOrShift: 'Deni (Shift Siang)',
    rating: 3,
    complaintOrFeedback:
      'Saya minta less sugar tetapi saat diminum terasa manis sekali seperti takaran biasa. Mohon lebih teliti untuk request gula.',
    status: 'baru',
    internalNotes: '',
    syncedToSheets: true,
  },
  {
    id: 'JJ-2026-003',
    createdAt: new Date(Date.now() - 3600000 * 18).toISOString(),
    customerName: 'Pelanggan Taman Dayu',
    customerPhone: '',
    tableOrOrderNo: 'Meja 08',
    menuCategory: 'Boba',
    menuItem: 'Matcha Latte (Rp 15.000)',
    staffNameOrShift: 'Siti (Shift Sore)',
    rating: 5,
    complaintOrFeedback: 'Boba kenyal dan matcha-nya pas, pelayanan ramah dan cepat!',
    status: 'selesai',
    internalNotes: 'Pelanggan puas.',
    syncedToSheets: true,
  },
];

function normalizeItem(rawItem: any): FeedbackSubmission {
  return {
    id: rawItem.id || `JJ-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
    createdAt: rawItem.createdAt || new Date().toISOString(),
    customerName: rawItem.customerName || 'Pelanggan (Anonim)',
    customerPhone: rawItem.customerPhone || '',
    tableOrOrderNo: rawItem.tableOrOrderNo || '-',
    menuCategory: rawItem.menuCategory || 'Jus Buah',
    menuItem: rawItem.menuItem || rawItem.drinkOrdered || 'Juice Alpukat (Rp 15.000)',
    staffNameOrShift: rawItem.staffNameOrShift || 'Shift Stand',
    rating:
      typeof rawItem.rating === 'number' && !isNaN(rawItem.rating)
        ? rawItem.rating
        : typeof rawItem.ratingOverall === 'number' && !isNaN(rawItem.ratingOverall)
        ? Math.round(rawItem.ratingOverall)
        : 5,
    complaintOrFeedback:
      rawItem.complaintOrFeedback ||
      rawItem.complaintDetails ||
      'Pelayanan cukup baik, tidak ada kendala khusus.',
    photoUrl: rawItem.photoUrl,
    status: rawItem.status === 'selesai' ? 'selesai' : rawItem.status === 'diproses' ? 'diproses' : 'baru',
    internalNotes: rawItem.internalNotes || '',
    resolvedAt: rawItem.resolvedAt,
    syncedToSheets: rawItem.syncedToSheets ?? true,
  };
}

export function getStoredFeedbacks(): FeedbackSubmission[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_SAMPLES));
      return INITIAL_SAMPLES;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_SAMPLES));
      return INITIAL_SAMPLES;
    }
    return parsed.map(normalizeItem);
  } catch (e) {
    console.error('Error reading localStorage:', e);
    return INITIAL_SAMPLES;
  }
}

export function saveStoredFeedback(item: FeedbackSubmission): FeedbackSubmission[] {
  const current = getStoredFeedbacks();
  const updated = [item, ...current];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return updated;
}

export function updateStoredFeedback(
  id: string,
  updates: Partial<FeedbackSubmission>
): FeedbackSubmission[] {
  const current = getStoredFeedbacks();
  const updated = current.map((item) => {
    if (item.id === id) {
      return {
        ...item,
        ...updates,
      };
    }
    return item;
  });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return updated;
}

export function getStoredSheetsConfig(): SheetsConfig | null {
  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function saveStoredSheetsConfig(config: SheetsConfig | null) {
  if (config) {
    localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
  } else {
    localStorage.removeItem(CONFIG_KEY);
  }
}
