import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import {
  initAuth,
  googleSignIn,
  logout,
  getAccessToken,
} from './lib/auth';
import {
  FeedbackSubmission,
  SheetsConfig,
} from './types/feedback';
import {
  getStoredFeedbacks,
  saveStoredFeedback,
  updateStoredFeedback,
  getStoredSheetsConfig,
  saveStoredSheetsConfig,
} from './lib/storage';
import { appendFeedbackToSheet } from './lib/sheets';
import { Header } from './components/Header';
import { CustomerForm } from './components/CustomerForm';
import { StaffDashboard } from './components/StaffDashboard';
import { TableQRView } from './components/TableQRView';
import { SheetsModal } from './components/SheetsModal';
import { AdminPinModal } from './components/AdminPinModal';
import { AlertCircle, CheckCircle2, Lock } from 'lucide-react';

export default function App() {
  // Navigation & Role State
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'customer' | 'dashboard' | 'qr'>('customer');

  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isSheetsModalOpen, setIsSheetsModalOpen] = useState(false);
  const [sheetsConfig, setSheetsConfig] = useState<SheetsConfig | null>(null);
  const [feedbacks, setFeedbacks] = useState<FeedbackSubmission[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );

  // Initialize storage & auth
  useEffect(() => {
    setFeedbacks(getStoredFeedbacks());
    setSheetsConfig(getStoredSheetsConfig());

    const unsubscribe = initAuth(
      (currentUser, token) => {
        setUser(currentUser);
        setAccessToken(token);
      },
      () => {
        setUser(null);
        setAccessToken(null);
      }
    );

    return () => {
      if (typeof unsubscribe === 'function') {
        unsubscribe();
      }
    };
  }, []);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setAccessToken(res.accessToken);
        showToast('success', `Berhasil masuk sebagai ${res.user.displayName || res.user.email}`);
      }
    } catch (err: any) {
      console.error(err);
      showToast('error', err.message || 'Gagal masuk dengan Google.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setUser(null);
      setAccessToken(null);
      showToast('success', 'Berhasil keluar dari akun Google.');
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveSheetsConfig = (newConfig: SheetsConfig | null) => {
    saveStoredSheetsConfig(newConfig);
    setSheetsConfig(newConfig);
    if (newConfig) {
      showToast('success', `Spreadsheet "${newConfig.spreadsheetTitle}" terhubung.`);
    }
  };

  // Submit new feedback / complaint
  const handleCustomerSubmit = async (
    submission: FeedbackSubmission
  ): Promise<{ success: boolean; synced: boolean; error?: string }> => {
    let isSynced = false;
    let syncError: string | undefined;

    const token = accessToken || (await getAccessToken());
    if (sheetsConfig && token) {
      try {
        await appendFeedbackToSheet(token, sheetsConfig.spreadsheetId, submission);
        isSynced = true;
      } catch (err: any) {
        console.error('Failed to append to Google Sheet:', err);
        syncError = err.message || 'Gagal menyinkronkan ke Google Sheet';
      }
    }

    const finalItem: FeedbackSubmission = {
      ...submission,
      syncedToSheets: isSynced,
    };

    const updated = saveStoredFeedback(finalItem);
    setFeedbacks(updated);

    return {
      success: true,
      synced: isSynced,
      error: syncError,
    };
  };

  // Update status from staff dashboard
  const handleUpdateStatus = (
    id: string,
    status: 'baru' | 'diproses' | 'selesai',
    notes?: string,
    staffNameOrShift?: string
  ) => {
    const updated = updateStoredFeedback(id, {
      status,
      internalNotes: notes,
      ...(staffNameOrShift ? { staffNameOrShift } : {}),
      resolvedAt: status === 'selesai' ? new Date().toISOString() : undefined,
    });
    setFeedbacks(updated);
    showToast('success', `Status tiket #${id} berhasil diperbarui.`);
  };

  // Bulk sync unsynced feedbacks to Google Sheets
  const handleSyncAll = async () => {
    const token = accessToken || (await getAccessToken());
    if (!token || !sheetsConfig) {
      setIsSheetsModalOpen(true);
      showToast('error', 'Silakan hubungkan akun Google dan spreadsheet terlebih dahulu.');
      return;
    }

    setIsSyncing(true);
    let syncedCount = 0;

    try {
      const unsynced = feedbacks.filter((f) => !f.syncedToSheets);
      if (unsynced.length === 0) {
        showToast('success', 'Semua data evaluasi sudah tersinkronisasi di Google Sheets.');
        return;
      }

      for (const item of unsynced) {
        try {
          await appendFeedbackToSheet(token, sheetsConfig.spreadsheetId, item);
          updateStoredFeedback(item.id, { syncedToSheets: true });
          syncedCount++;
        } catch (e) {
          console.error(`Failed to sync item ${item.id}`, e);
        }
      }

      setFeedbacks(getStoredFeedbacks());
      showToast('success', `${syncedCount} masukan berhasil disinkronkan ke Google Sheets!`);
    } catch (err: any) {
      showToast('error', err.message || 'Terjadi kesalahan saat menyinkronkan data.');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleUnlockAdmin = () => {
    setIsAdmin(true);
    setActiveTab('dashboard');
    showToast('success', 'Mode Pengelola / Pemilik Aktif (PIN Terverifikasi)');
  };

  const handleLockAdmin = () => {
    setIsAdmin(false);
    setActiveTab('customer');
    showToast('success', 'Kunci aktif. Tampilan kembali ke Formulir Pelanggan.');
  };

  const pendingComplaintsCount = feedbacks.filter(
    (f) => f.status !== 'selesai'
  ).length;

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900 selection:bg-amber-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 bg-stone-900 text-white rounded-2xl shadow-xl border border-stone-800 text-xs font-semibold animate-in fade-in slide-in-from-bottom-3 duration-200">
          {toastMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Header: adapts automatically between Customer View & Admin View */}
      <Header
        isAdmin={isAdmin}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        user={user}
        sheetsConfig={sheetsConfig}
        onOpenSheetsModal={() => setIsSheetsModalOpen(true)}
        onOpenAdminModal={() => setIsAdminModalOpen(true)}
        onLockAdmin={handleLockAdmin}
        onLogout={handleLogout}
        pendingComplaintsCount={pendingComplaintsCount}
      />

      {/* Main View Area */}
      <main className="flex-1">
        {/* If not admin, always render Customer Form */}
        {!isAdmin || activeTab === 'customer' ? (
          <CustomerForm
            onSubmit={handleCustomerSubmit}
            sheetsConfig={sheetsConfig}
          />
        ) : activeTab === 'dashboard' ? (
          <StaffDashboard
            feedbacks={feedbacks}
            sheetsConfig={sheetsConfig}
            onOpenSheetsModal={() => setIsSheetsModalOpen(true)}
            onUpdateStatus={handleUpdateStatus}
            onSyncAll={handleSyncAll}
            isSyncing={isSyncing}
          />
        ) : (
          <TableQRView onBackToCustomer={() => setActiveTab('customer')} />
        )}
      </main>

      {/* Admin PIN Protection Modal */}
      <AdminPinModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        onUnlock={handleUnlockAdmin}
        user={user}
        onGoogleLogin={handleLogin}
      />

      {/* Google Sheets Integration Modal */}
      <SheetsModal
        isOpen={isSheetsModalOpen}
        onClose={() => setIsSheetsModalOpen(false)}
        user={user}
        accessToken={accessToken}
        sheetsConfig={sheetsConfig}
        onSaveConfig={handleSaveSheetsConfig}
        onLogin={handleLogin}
        isLoggingIn={isLoggingIn}
      />

      {/* Quiet Non-Intrusive Footer */}
      <footer className="mt-auto border-t border-stone-200 bg-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-stone-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-stone-800">JUVE JUICE</span>
            <span aria-hidden="true">·</span>
            <span>New Food Terrace, The Taman Dayu, Pandaan</span>
          </div>

          <div className="flex items-center gap-4">
            {!isAdmin ? (
              <button
                onClick={() => setIsAdminModalOpen(true)}
                className="flex items-center gap-1.5 text-stone-400 hover:text-stone-700 transition-colors"
                title="Khusus Pemilik & Pengelola Stand"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Akses Pengelola Stand</span>
              </button>
            ) : (
              <>
                <button
                  onClick={() => setActiveTab('customer')}
                  className="hover:text-stone-900 transition-colors"
                >
                  Form Pelanggan
                </button>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="hover:text-stone-900 transition-colors"
                >
                  Monitor Stand
                </button>
                <button
                  onClick={() => setActiveTab('qr')}
                  className="hover:text-stone-900 transition-colors"
                >
                  Cetak QR
                </button>
                <button
                  onClick={() => setIsSheetsModalOpen(true)}
                  className="hover:text-stone-900 transition-colors text-emerald-700 font-medium"
                >
                  Google Sheets
                </button>
                <button
                  onClick={handleLockAdmin}
                  className="text-amber-700 font-bold hover:underline"
                >
                  Kunci Mode
                </button>
              </>
            )}
          </div>
        </div>
      </footer>
    </div>
  );
}
